//
//  ViewController.h
//  PlotExampleApplication
//
//  Copyright (c) 2015 Floating Market B.V. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MailComposerHelper;

@interface ViewController : UIViewController {
    IBOutlet UISwitch* plotEnableSwitch;
    IBOutlet UILabel* versionLabel;
}

- (IBAction)plotEnableSwitch:(UISwitch *)plotSwitch;

@end

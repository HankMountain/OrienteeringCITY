//
//  ViewController.m
//  PlotExampleApplication
//
//  Copyright (c) 2015 Floating Market B.V. All rights reserved.
//

#import "ViewController.h"
#import "Plot.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    versionLabel.text = [NSString stringWithFormat:@"Plot version: %@", [Plot version]];
    
    BOOL plotEnabled = [Plot isEnabled];
    if ([plotEnableSwitch isOn] != plotEnabled) {
        [plotEnableSwitch setOn:plotEnabled];
    }
}

-(void)updateEnabledSwitch {
    
}

- (void)plotEnableSwitch:(UISwitch *)plotSwitch {
    if (plotSwitch.on) {
        [Plot enable];
    } else {
        [Plot disable];
    }
}

@end

//
//  AppDelegate.m
//  PlotExampleApplication
//
//  Copyright (c) 2015 Floating Market B.V. All rights reserved.
//

#import "AppDelegate.h"
#import "Plot.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    

    [Plot initializeWithLaunchOptions:launchOptions delegate:self];
    return YES;
}

-(void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification {
    [Plot handleNotification:notification];
}

-(void)applicationWillResignActive:(UIApplication *)application {
    //Stop tasks here that aren't needed in the background
    //Else these tasks will continue in the background and
    //will reduce the battery time.
    //
    //Examples of task that should be stopped is GPS usage
    //and timers should be paused
}


//Optional feature: Notification Filter
//Change notifications before they are shown or prevent notifications from being shown
-(void)plotFilterNotifications:(PlotFilterNotifications*)filterNotifications {
    NSArray<UILocalNotification*>* notifications = filterNotifications.uiNotifications;
    for (UILocalNotification* notification in notifications) {
        NSString* newText = [NSString stringWithFormat:@"Because it is %@: %@", [self getDayOfWeek], notification.alertBody];
        notification.alertBody = newText;
    }
    [filterNotifications showNotifications:notifications];
}

-(NSString*)getDayOfWeek {
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [calendar components:NSWeekdayCalendarUnit fromDate:[NSDate date]];
    int dayOfWeek = (int) [components weekday];
    
    switch (dayOfWeek) {
        case 1: return @"Sunday";
        case 2: return @"Monday";
        case 3: return @"Tuesday";
        case 4: return @"Wednesday";
        case 5: return @"Thursday";
        case 6: return @"Friday";
        case 7: return @"Saturday";
        default: return @"???";
    }
}

@end

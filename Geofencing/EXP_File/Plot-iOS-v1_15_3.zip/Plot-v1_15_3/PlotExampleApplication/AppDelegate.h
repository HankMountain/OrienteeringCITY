//
//  AppDelegate.h
//  PlotExampleApplication
//
//  Copyright (c) 2015 Floating Market B.V. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Plot.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate, PlotDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

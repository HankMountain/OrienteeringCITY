# swift-geofencing
Example of geofencing iOS app in swift.

About geofencing: https://en.wikipedia.org/wiki/Geo-fence

Based on this iOS core location services tutorial http://www.raywenderlich.com/95014/geofencing-ios-swift

TwitterBirdAnimation
====================

Replicating Twitter's bird zoom startup animation

Read [the accompanying blog post](http://iosdevtips.co/post/88481653818/twitter-ios-app-bird-zoom-animation)

![twitter bird animation](http://media.tumblr.com/10cc0ba92377a2cba9fb35c9943fd2ca/tumblr_inline_n6zpokNxpC1qh9cw7.gif)

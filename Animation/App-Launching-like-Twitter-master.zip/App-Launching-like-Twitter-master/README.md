# App Launching like Twitter
startup animation like Twitter iOS app!

![DEMO](./animation.gif)

## Licence
This software is released under the MIT License, see LICENSE.txt.
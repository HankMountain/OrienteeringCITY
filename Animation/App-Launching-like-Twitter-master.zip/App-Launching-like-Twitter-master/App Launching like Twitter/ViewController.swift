//
//  ViewController.swift
//  App Launching like Twitter
//
//  Created by Daiki Okumura on 2015/05/08.
//  Copyright (c) 2015 Daiki Okumura. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

